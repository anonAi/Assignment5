package iss.java.mail;

import java.io.IOException;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.sun.mail.smtp.SMTPTransport;
//zghenqin@163.com
//
public class Mai2014302580374 implements IMailService {
	public String smtpHost = "smtp.163.com";
	public int smtpPort = 465;
	public Properties props = null;
	public Session session = null;
	public Message message = null;
	public String popHost = "pop.163.com";
	public int popPort = 995;
	public Properties popProps = null;
	public Session popSession = null;
	public Store store = null;
	public Folder folder = null;
	
	@Override
	public void connect() throws MessagingException {
		// TODO Auto-generated method stub
		props = new Properties();
		props.put("mail.smtp.ssl.enable", true);
		props.put("mail.smtp.port", smtpPort);
		props.put("mail.smtp.host",  smtpHost);
		props.put("mail.smtp.auth", true);
		session = Session.getDefaultInstance(props, new Authenticator(){
			@Override
			protected PasswordAuthentication getPasswordAuthentication(){
				return new PasswordAuthentication("zghenqin@163.com", "orukpchcqbnryegh");
			}
		});
		popProps = new Properties();
		popProps.put("mail.pop3.ssl.enable",  true);
		popProps.put("mail.pop3.host",  popHost);
		popProps.put("mail.pop3.port", popPort);
		popSession = Session.getInstance(popProps);
		store = popSession.getStore("pop3");
		store.connect("zghenqin@163.com", "orukpchcqbnryegh");
		
		System.out.printf("connect OK\n");
	}

	@Override
	public void send(String recipient, String subject, Object content) throws MessagingException {
		// TODO Auto-generated method stub
		message = new MimeMessage(session);
		message.setFrom(new InternetAddress("zghenqin@163.com"));
		message.addRecipient(Message.RecipientType.TO,  new InternetAddress(recipient));
		message.setSubject(subject);
		message.setText(content.toString());
		Transport.send(message);
	}
	
	public String content = "";
	public String subject = "";
	
	@Override
	public boolean listen() throws MessagingException {
		// TODO Auto-generated method stub
		folder = store.getFolder("INBOX");
		folder.open(Folder.READ_ONLY);
		int i = folder.getMessageCount();
		Message message = folder.getMessage(i);
		if(message.getFrom()[0].toString().equals("issjava2015@foxmail.com")){
			content = message.toString();
			subject = message.getSubject();
			return true;
		}
		if(message.getSubject().equals("自动回复:java作业1_2014302580374")){
			content = message.toString();
			subject = message.getSubject();
			return true;
		}
		return false;
	}

	@Override
	public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
		// TODO Auto-generated method stub
		return content;
	}

}
